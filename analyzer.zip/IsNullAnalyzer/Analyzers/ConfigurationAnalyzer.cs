﻿using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Diagnostics;
using Microsoft.CodeAnalysis;
using System.Collections.Immutable;
using System.Linq;
using System.IO;
using Newtonsoft.Json.Linq;

namespace MyAnalyzer.Analyzers
{
    [DiagnosticAnalyzer(LanguageNames.CSharp)]
    public class ConfigurationAnalyzer : DiagnosticAnalyzer
    {
        private const string DiagnosticId = "CFG001";
        private const string Title = "Configuração Inválida";
        private const string MessageFormat = "{0}";
        private const string Category = "Configuração";
        private const string StringVazia = "A string key de configuração não pode ser vazia";
        private const string StringInexistente = "A string key de configuração não existe no arquivo appsettings.json";

        private static readonly DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Error, isEnabledByDefault: true);

        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => ImmutableArray.Create(Rule);

        public override void Initialize(AnalysisContext context)
        {
            context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
            context.EnableConcurrentExecution();
            context.RegisterSyntaxNodeAction(AnalyzeNode, SyntaxKind.ClassDeclaration);
        }

        private void AnalyzeNode(SyntaxNodeAnalysisContext context)
        {
            var classDeclaration = (ClassDeclarationSyntax)context.Node;
            var semanticModel = context.SemanticModel;

            var fields = classDeclaration.Members.OfType<FieldDeclarationSyntax>();
            foreach (var field in fields)
            {
                var variable = field.Declaration.Variables.First();
                var fieldType = semanticModel.GetTypeInfo(field.Declaration.Type).Type;

                if (fieldType != null && fieldType.ToDisplayString() == "Microsoft.Extensions.Configuration.IConfiguration")
                {
                    // Verifique se a variável está sendo usada e se a string não está em branco
                    var root = field.SyntaxTree.GetRoot();
                    var identifierNameSyntaxes = root.DescendantNodes()
                        .OfType<IdentifierNameSyntax>()
                        .Where(id => id.Identifier.Text == variable.Identifier.Text);

                    foreach (var identifier in identifierNameSyntaxes)
                    {
                        var parent = identifier.Parent as ElementAccessExpressionSyntax;
                        if (parent != null)
                        {
                            var argument = parent.ArgumentList.Arguments.First();
                            var argumentString = semanticModel.GetConstantValue(argument.Expression).ToString();
                            if (string.IsNullOrEmpty(argumentString))
                            {
                                var diagnostic = Diagnostic.Create(Rule, argument.GetLocation(), StringVazia);
                                context.ReportDiagnostic(diagnostic);
                            }
                            else
                            {
                                var filePath = context.Compilation.SyntaxTrees.First().FilePath;
                                var projectDirectory = Directory.GetParent(filePath).Parent.Parent.FullName;
                                var projectName = Path.GetFileNameWithoutExtension(context.Compilation.AssemblyName);
                                var appSettingsPath = Path.Combine(projectDirectory, projectName, "appsettings.json");

                                if (!AppSettingsKeyExists(appSettingsPath, argumentString))
                                {
                                    var diagnostic = Diagnostic.Create(Rule, argument.GetLocation(), StringInexistente);
                                    context.ReportDiagnostic(diagnostic);
                                }
                            }
                        }
                    }
                }
            }
        }

        private bool AppSettingsKeyExists(string appsettingsPath, string key)
        {
            if (!File.Exists(appsettingsPath))
                return false;

            try
            {
                var jsonContent = File.ReadAllText(appsettingsPath);
                var jsonObject = JObject.Parse(jsonContent);

                if (jsonObject == null)
                    return false;

                var keyParts = key.Split(':');
                JToken currentNode = jsonObject;

                foreach (var part in keyParts)
                {
                    if (currentNode[part] != null)
                    {
                        currentNode = currentNode[part];
                    }
                    else
                    {
                        return false;
                    }
                }

                // Verifica se o valor final não é um objeto JSON (ou seja, se não contém outras chaves)
                if (currentNode.Type == JTokenType.Object)
                {
                    return false;
                }

                return currentNode != null && !string.IsNullOrEmpty(currentNode.ToString());
            }
            catch
            {
                return false;
            }
        }
    }
}