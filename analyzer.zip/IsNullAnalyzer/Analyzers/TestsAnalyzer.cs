﻿//using Microsoft.CodeAnalysis.CSharp.Syntax;
//using Microsoft.CodeAnalysis.CSharp;
//using Microsoft.CodeAnalysis.Diagnostics;
//using Microsoft.CodeAnalysis;
//using System.Collections.Immutable;
//using System.Linq;

//namespace MyAnalyzer.Analyzers
//{
//    [DiagnosticAnalyzer(LanguageNames.CSharp)]
//    public class TestsAnalyzer : DiagnosticAnalyzer
//    {
//        private const string DiagnosticId = "MY001";
//        private const string Title = "Método sem Teste";
//        private const string MessageFormat = "O método '{0}' não possui a variável 'url'.";
//        private const string Category = "Testes";

//        private static DiagnosticDescriptor Rule = new DiagnosticDescriptor(DiagnosticId, Title, MessageFormat, Category, DiagnosticSeverity.Error, isEnabledByDefault: true);

//        public override ImmutableArray<DiagnosticDescriptor> SupportedDiagnostics => ImmutableArray.Create(Rule);

//        public override void Initialize(AnalysisContext context)
//        {
//            context.ConfigureGeneratedCodeAnalysis(GeneratedCodeAnalysisFlags.None);
//            context.EnableConcurrentExecution();
//            context.RegisterSyntaxNodeAction(AnalyzeNode, SyntaxKind.ClassDeclaration);
//        }

//        private void AnalyzeNode(SyntaxNodeAnalysisContext context)
//        {
//            //var methodDeclaration = (MethodDeclarationSyntax)context.Node;
//            //var methodName = methodDeclaration.Identifier.Text;

//            // Verifica se o método possui a variável "url"
//            //var hasUrlVariable = methodDeclaration.DescendantNodes()
//            //    .OfType<VariableDeclaratorSyntax>()
//            //    .Any(v => v.Identifier.Text == "url");

//            // Se o método não possuir a variável "url", relatar um diagnóstico
//            //if (!hasUrlVariable)
//            //{
//                //var diagnostic = Diagnostic.Create(Rule, Location.None, "methodName");
//                //context.ReportDiagnostic(diagnostic);
//            //}

//            var classDeclaration = (ClassDeclarationSyntax)context.Node;
//            var className = classDeclaration.Identifier.Text;

//            var fields = classDeclaration.Members.OfType<FieldDeclarationSyntax>();
//            foreach (var field in fields)
//            {
//                var variable = field.Declaration.Variables.First();
//                var fieldType = field.Declaration.Type.ToString();
//                var semanticModel = context.SemanticModel.GetTypeInfo(field.Declaration.Type).Type.ToDisplayString();

//                if (fieldType == "IDogImageService")
//                {
//                    var diagnostic = Diagnostic.Create(Rule, field.Declaration.Type.GetLocation(), className);
//                    context.ReportDiagnostic(diagnostic);
//                }
//            }
//        }
//    }
//}
