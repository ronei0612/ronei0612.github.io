﻿//using Microsoft.CodeAnalysis.CodeActions;
//using Microsoft.CodeAnalysis.CodeFixes;
//using Microsoft.CodeAnalysis.CSharp.Syntax;
//using Microsoft.CodeAnalysis.CSharp;
//using Microsoft.CodeAnalysis;
//using MyAnalyzer.Analyzers;
//using System.Collections.Immutable;
//using System.Composition;
//using System.Threading.Tasks;
//using System.Threading;
//using System.Linq;

//namespace MyAnalyzer.CodeFixes
//{
//    [ExportCodeFixProvider(LanguageNames.CSharp, Name = nameof(LoggerCodeFixProvider)), Shared]
//    public class LoggerCodeFixProvider : CodeFixProvider
//    {
//        private const string Title = "Corrigir tipo de ILogger";

//        public sealed override ImmutableArray<string> FixableDiagnosticIds => ImmutableArray.Create(LoggerAnalyzer.DiagnosticId);

//        public sealed override FixAllProvider GetFixAllProvider() => WellKnownFixAllProviders.BatchFixer;

//        public sealed override async Task RegisterCodeFixesAsync(CodeFixContext context)
//        {
//            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);
//            var diagnostic = context.Diagnostics.First();
//            var diagnosticSpan = diagnostic.Location.SourceSpan;

//            var fieldDeclaration = root.FindToken(diagnosticSpan.Start).Parent.AncestorsAndSelf().OfType<FieldDeclarationSyntax>().First();

//            context.RegisterCodeFix(
//                CodeAction.Create(
//                    title: Title,
//                    createChangedDocument: c => CorrectLoggerTypeAsync(context.Document, fieldDeclaration, c),
//                    equivalenceKey: Title),
//                diagnostic);
//        }

//        private async Task<Document> CorrectLoggerTypeAsync(Document document, FieldDeclarationSyntax fieldDeclaration, CancellationToken cancellationToken)
//        {
//            var variable = fieldDeclaration.Declaration.Variables.First();
//            var fieldType = (IdentifierNameSyntax)fieldDeclaration.Declaration.Type;

//            var classDeclaration = (ClassDeclarationSyntax)fieldDeclaration.Parent;
//            var className = classDeclaration.Identifier.Text;

//            var newFieldType = SyntaxFactory.ParseTypeName($"ILogger<{className}>")
//                .WithTriviaFrom(fieldType);

//            var newFieldDeclaration = fieldDeclaration.WithDeclaration(
//                fieldDeclaration.Declaration.WithType(newFieldType));

//            var root = await document.GetSyntaxRootAsync(cancellationToken);
//            var newRoot = root.ReplaceNode(fieldDeclaration, newFieldDeclaration);

//            return document.WithSyntaxRoot(newRoot);
//        }
//    }
//}
